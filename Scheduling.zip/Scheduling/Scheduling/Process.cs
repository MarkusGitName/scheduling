﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Scheduling
{
    class Process 
    {
        public String Name;
        public int Time;
        public int priority;

        public Process(String s, int t, int p)
        {
            setName(s);
            setTime(t);
            setPriority(p);
        }
        public string getName()
        {
            return Name;
        }
        public int getTime()
        {
            return Time;
        }
        public int getPriority()
        {
            return priority;
        }

        public void setName(String n)
        {
            try
            {
                Name = n;
            }
             catch(Exception e)
            {
                MessageBox.Show("Please enter a letter as process name");
            }
}
        public void setTime(int t)
        {
            try
            {
                Time = t;
            }
            catch (Exception e)
            {
                MessageBox.Show("Process size must be an integer");
            }          
        }
        public void setPriority(int p)
        {
            try
            {
                if (p < 0)
                {
                    priority = 1;
                }
                priority = p;

            }catch(Exception e)
            {
                MessageBox.Show("Priority must be 1-10");
            }
           
        }
        public String toString()
        {
            return "name: " + getName() + ".  time: " + getTime()+".  priority: "+getPriority();
        }
    }
}
