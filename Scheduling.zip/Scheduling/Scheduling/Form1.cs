﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Scheduling
{
    public partial class Form1 : Form
    {   //Verklaring van al die nodige lysse
        private List<Process> Hooflys = new List<Process>();//hoof lys verander nooit
        //lyste nodig vir verskillende algerithmes
        private List<Process> KortseEerstelys = new List<Process>();
        private List<Process> Priotitylys = new List<Process>();
        private List<Process> RoundRobinList = new List<Process>();
        //lyste nodig vir multiple qeue algirithme
        private List<Process> Batch = new List<Process>(); 
        private List<Process> Game = new List<Process>();
        private List<Process> primary = new List<Process>();
        private List<Process> secondary = new List<Process>();
        public Form1()
        {
            InitializeComponent();
          
        }

        private void button1_Click(object sender, EventArgs e)//Add Process Button
        {
           //Ddd to hooflys
            Process pr = new Process(textBox1.Text, Convert.ToInt32(textBox2.Text), Convert.ToInt32(domainUpDown1.Text));
            Hooflys.Add(pr);

            //Add to Multiple qeues.
            if(comboBox2.Text == "Batch"||comboBox2.Text == "")
            {
                Batch.Add(pr);
            }           
           else if (comboBox2.Text == "Game")
            {
                Game.Add(pr);
            }
           else if (comboBox2.Text == "Primary")
            {
                primary.Add(pr);
            }
           else if (comboBox2.Text == "Secondary")
            {
                secondary.Add(pr);
            }
            
            //reset textboxes
            textBox5.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            
            //Display Processes and process types in textbox processes
            foreach(Process p in Hooflys)
            {
                textBox5.Text+= p.toString()+"\n\r\n\r";
            }
           // textBox5.Text+= "\n\r\n\r"+"Batch:-Lenght:  "+Batch.Count+".  Folows:  ";  
         
           /* foreach (Process p in Batch)
            {
                textBox5.Text+= p.toString()+"\n\r\n\r";
            }
            textBox5.Text+= "\n\r\n\r"+"Primary:-Length:  "+primary.Count+".  Folows:  "; 
            
            foreach (Process p in primary)
            {
                textBox5.Text+= p.toString()+"\n\r\n\r";
            }
            textBox5.Text+= "\n\r\n\r"+"Secondary:- Length:  "+secondary.Count+".  Folows:  "; 
            
            foreach (Process p in secondary)
            {
                textBox5.Text+= p.toString()+"\n\r\n\r";
            }
            textBox5.Text+= "\n\r\n\r"+"Game:- Length:  "+Game.Count+".  Folows:  "; 
            foreach (Process p in Game)
            {
                textBox5.Text+= p.toString()+"\n\r\n\r";
            }*/

        }

        private void button4_Click(object sender, EventArgs e)//Aply algorithm button
        {
            //Sorteer lyste met sorting methods, of berei lyste foor vir die gekose algerithme om te run, multi qeue nie voorbery nodig nie 
            if(comboBox1.Text =="Shortest Job First")
            {
                KortseEerstelys = Sort(Hooflys);
                label11.Text = "Shortest Job First";
                label12.Text = "Ready";
            }
            else if (comboBox1.Text =="Round Robin")
            {
                RoundRobinList = Hooflys;
                label11.Text = "Round Robin";
                label12.Text = "Ready";
            }
           else if (comboBox1.Text =="Priority")
            {
                Priotitylys = SortPriority(Hooflys);
                label11.Text = "Priority";
                label12.Text = "Ready";
            }
            else if (comboBox1.Text =="Multi Queue")
            {
                label11.Text = "Multi Qeue";
                label12.Text = "Ready";
            }
            else {  label12.Text = "No algorithm applyed"; }
          
        }
        //Shortest job first sorteering algerithme
        private List<Process> Sort(List<Process> L)
        {
            Process[] tempAr = new Process[L.Count];
            Process[] arr = new Process[L.Count];
            List<Process> newL = new List<Process>();
            int c = 0;
            foreach (Process p in L)
            {
                tempAr[c] = p;
                c++;
            }
            Process ruil;
            for (int y = 0; y < arr.Length; y++)
                for (int i = 0; i < arr.Length; i++)
                {
                    if (i > 0)
                    {
                        if (tempAr[i - 1].getTime() > tempAr[i].getTime())
                        {
                            ruil = tempAr[i - 1];
                            tempAr[i - 1] = tempAr[i];
                            tempAr[i] = ruil;
                        }
                    }                 
                }
            foreach (Process p in tempAr)
            {
                newL.Add(p);
            }
            return newL;
        }
        //priority sorteer algerithme
        private List<Process> SortPriority(List<Process> L)
        {
            Process[] tempAr = new Process[L.Count];
            Process[] arr = new Process[L.Count];
            List<Process> newL = new List<Process>();
            int c = 0;
            foreach (Process p in L)
            {
                tempAr[c] = p;
                c++;
            }
            Process ruil;
            for (int y = 0; y < arr.Length; y++)
                for (int i = 0; i < arr.Length; i++)
                {
                    if (i > 0)
                    {
                        if (tempAr[i - 1].getPriority() <= tempAr[i].getPriority())
                        {
                            ruil = tempAr[i - 1];
                            tempAr[i - 1] = tempAr[i];
                            tempAr[i] = ruil;
                        }
                    }
                    else
                    {

                    }
                }
            foreach (Process p in tempAr)
            {
                newL.Add(p);
            }
            return newL;
        }

        //start pocess button
        private void button3_Click(object sender, EventArgs e)
        {
            label12.Text = "Running";
            textBox6.Text = "";
            textBox7.Text = "";
            if (comboBox1.Text == "Shortest Job First")
            {
                foreach(Process p in KortseEerstelys)
                {        
                    int i = 1;
                    String name = p.getName();
                    textBox7.Text += "Priority: " + p.getPriority() + "\t\t";
                    while (i <= p.getTime())
                    {
                        textBox6.Text += name + i.ToString() + "  ";
                        textBox7.Text += name + i.ToString();
                        i++;
                    }
                    textBox7.Text += "\n\r\n ";

                }
            }
            if (comboBox1.Text == "Round Robin")
            {
                List<Process> temp = Hooflys;
                int i = temp.Count;
                int cycle = 0;
                textBox7.Text += "Start:\n\r\n\r";
                while (i != 0)
                {
                    foreach (Process p in temp)
                    {
                        int time = p.getTime() - (5 * cycle);                  
                        if(time>=0)
                        {
                            textBox7.Text += "Quantum:  ";
                           for (int  x =0;x<5; x++)
                            {
                               textBox7.Text += p.getName()+((p.getTime()-(5*cycle))-x).ToString()+"  ";
                            }
                            textBox7.Text += "\n\r\n\r"  ;
                        }
                        else if(time>=-5)
                        {
                            i--;
                        }
                       
                    }
                    cycle++;
                    textBox7.Text +=" \n\r\n\r ";
                }
            }
            if (comboBox1.Text == "Priority")
            {
                foreach (Process p in Priotitylys)
                {
                    int i = 1;
                    String name = p.getName();
                    textBox7.Text += "Priority: " + p.getPriority() + "\t\t";
                    while (i <= p.getTime())
                    {
                        textBox6.Text += name + i.ToString() + "  ";
                        textBox7.Text += name + i.ToString();
                        i++;
                    }
                    textBox7.Text += "\n\r\n ";

                }
            }
            if (comboBox1.Text == "Multi Queue")
            {
                List<Process> temp = Hooflys;
                int i = temp.Count;
                int cycle = 0;
                textBox7.Text += "Start:\n\r\n\r";
                int quanta = 1;
                while (i != 0)
                {
                    quanta = quanta * 2;
                    foreach (Process p in temp)
                    {
                        int time = p.getTime() - (5 * cycle);
                        if (time >= 0)
                        {
                            textBox7.Text += "Quantum:  ";
                            for (int x = 0; x < quanta; x++)
                            {
                                textBox7.Text += p.getName() + ((p.getTime() - (5 * cycle)) - x).ToString() + "  ";
                            }
                            textBox7.Text += "\n\r\n\r";
                        }
                        else 
                        {
                            i--;
                        }

                    }
                    cycle++;

                    textBox7.Text += " \n\r\n\r ";
                }
                /*
                List<TypeClass> newList = new List<TypeClass>();
                TypeClass game = new TypeClass(Game," Game: ");
                TypeClass batch = new TypeClass(Batch,"Batch: ");
                TypeClass prim = new TypeClass(primary,"Primary:  ");
                TypeClass sec = new TypeClass(secondary, "Secondary:  ");

                newList.Add(game);                
                newList.Add(prim);
                newList.Add(sec);
                newList.Add(batch);
                int cycle = 0;
                int i= 0;
                while (i <= 3)
                {
                    foreach (TypeClass t in newList)
                    {
                        String disp =String.Format("{0,10} \t\t",t.getName());
                       String[] arr = t.getPro();
                        int j = 0;
                        if (arr.Length > 20 * (cycle + 1))
                        {
                            for (int x = 20 * cycle; x < 20 * (cycle + 1); x++)
                            {
                                textBox6.Text +=arr[x].ToString()+ "  ";
                               
                                disp += arr[x].ToString();
                               
                                j++;
                            }
                            textBox7.Text +=disp;
                        }
                        else if(arr.Length-(20 * (cycle + 1)) <=-20)
                        {  }
                        else
                        {                          
                                for (int x = 20 * cycle; x < 20 * (cycle + 1); x++)
                                {
                                    try
                                    {
                                         textBox6.Text +=arr[x].ToString()+ "  ";
                                         disp += arr[x].ToString();
                                         j++;
                                    }
                                    catch { break; }
                                }
                            textBox7.Text += disp;
                            i++;                           
                        }
                        textBox7.Text += "\n\r\n\r   ";
                    }
                    cycle++;
                }textBox7.Text += "\n\r\n\r End \n\r\n\r";*/
             }
            label12.Text = "Done";
            }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
