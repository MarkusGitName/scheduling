﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Scheduling
{
    class TypeClass
    {
        public List<Process> process;        
        public String[] FulP;
        public String type;
        public TypeClass(List<Process> p,String t)
        {
            process = p;          
            setFullProcess(p);
            type = t;
        }
        public String getName()
        {
            return type;
        }
        public void setFullProcess(List<Process> pp)
        {
           
            List<String> newProcess = new List<String>();
            foreach (Process p in pp)
            {
                for(int i = p.getTime(); i >0 ;i--)
                {
                    newProcess.Add(p.getName() + i.ToString());
                }
            }
            String[] nuweP = new String[newProcess.Count];
            int j = 0;
            foreach(String s in newProcess)
            {
               
                nuweP[j] = s;
                j++;
               // MessageBox.Show(nuweP[j].ToString());
            }

            FulP = nuweP;
        }
        public String[] getPro()
        {
            String show = "";
            foreach (String s in FulP)
            {
                show += s + "  " + FulP.Length;
            }
           // MessageBox.Show(show);
            return FulP;
        }
        public void display()
        {
            String show = "";
            foreach(String s in FulP)
            {
                show += s + "  "+FulP.Length;
            }
            //MessageBox.Show(show);

        }

    }
}
